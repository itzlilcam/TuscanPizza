$(function(){
    $("#nav-placeholder").load("nav");
    });